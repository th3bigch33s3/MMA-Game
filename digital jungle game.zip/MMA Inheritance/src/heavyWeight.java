import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class heavyWeight extends boxer implements fighter {
	private String fighterName;
	private int fighterSpeed, fighterPower, fighterStamina, fighterToughness, fighterHealth;
	private float fighterWeight, fighterHeight; // all heights are in Centimeters
	
	// default constructor
	public heavyWeight() {
		// creates a random fighter
		setFighterName("Tyson Fury");
		setFighterSpeed(85);
		setFighterToughness(99);
		setFighterStamina(99);
		setFighterPower(70);
		setFighterHeight(204.21f);
		setFighterWeight(260f);
		setFighterHealth(100);
	}
	
	// custom creation of a boxer
	public heavyWeight(String fighterName, int fighterSpeed, int fighterPower, int fighterToughness, int fighterStamina,
			float fighterHeight, float fighterWeight) {
		// creates a random fighter
		setFighterName(fighterName);
		setFighterSpeed(fighterSpeed);
		setFighterPower(fighterPower);
		setFighterToughness(fighterToughness);
		setFighterStamina(fighterStamina);
		setFighterHeight(fighterHeight);
		setFighterWeight(fighterWeight);
		setFighterHealth(100);
	}
	
	@Override
	public void moveset(heavyWeight boxer,heavyWeight opponent ) {
		if(boxer.getFighterHealth()<=0) {
			System.out.println("You got hit with a good shot and your fighter can't continue!");
		}
		
		else {
		System.out.println("It's your move. Type in the number associated with the move: ");
		
		boolean isNum = false;
		Scanner scanner = new Scanner (System.in);
		int moveSelect =0;
		
		do {
			try {
				System.out.println("1) Jab \n"
						+ "2) Cross \n"
						+ "3) Left Hook To The Body \n"
						+ "4) Left Hook To the Head \n"
						+ "5) Right Hook To The Body \n"
						+ "6) Right Hook To The Head \n"
						+ "7) Uppercut \n"
						+ "8) Clinch \n");
				
				moveSelect = scanner.nextInt();
				
				switch(moveSelect) {
				case 1: jab(boxer, opponent);
						isNum = true;
						break;
				case 2: cross(boxer, opponent);
						isNum = true;
						break;
				case 3: leftHookBody(boxer, opponent);
						isNum = true;
						break;
				case 4: leftHookHead(boxer, opponent);
				isNum = true;

				break;
				case 5: rightHookBody(boxer, opponent);
				isNum = true;

				break;
				case 6: rightHookHead(boxer, opponent);
				isNum = true;

				break;
				case 7: uppercut(boxer, opponent);
				isNum = true;

				break;
				case 8: clinch(boxer, opponent);
				isNum = true;

				break;
				default: System.out.println("Not a valid Selection!");
				}


				// computer moveset
				

				
			}
			// not a real int
			catch(InputMismatchException e) {
				System.out.println("This is not a number. Please Type in a real number!");
				// reset the scanner and set it to next so it is ready to fetch the next information
				scanner.reset();
				scanner.next();
			}
			
		} while(isNum == false);
		
		
		// computer's move
		computerMoveset(boxer, opponent);
	}
		
	}
		
	public void computerMoveset(heavyWeight boxer, heavyWeight computer){
		if(computer.getFighterHealth() <=0) {
			System.out.println(computer.getFighterName() + " has fallen to the canvas and can't get up!");
		}
		
		else {
		System.out.println("The computer is making a move!");

		Random ran = new Random();		
		int moveSelect = ran.nextInt(8 - 1 + 1) + 1;

				switch(moveSelect) {
				case 1: jab(computer, boxer);
						break;
				case 2: cross(computer, boxer);
						break;
				case 3: leftHookBody(computer,boxer);
						break;
				case 4: leftHookHead(computer,boxer);
				break;
				case 5: rightHookBody(computer,boxer);
				break;
				case 6: rightHookHead(computer,boxer);
				break;
				case 7: uppercut(computer,boxer);
				break;
				case 8: clinch(computer,boxer);
				break;
				
				default: System.out.println("Not a valid Selection!");
				}
		}
	}
	
	
	// the first person is the attacker the last is the defender getting hit
	
	@Override
	public void damage(heavyWeight attacker, int damage, heavyWeight defender) {
		defender.setFighterHealth(defender.getFighterHealth() - damage);
		System.out.println(attacker.getFighterName() + " has inflicted " + damage + " health points");
	}

	@Override
	public void jab(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.01*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the Jab");
		damage(attacker, damage, defender);
	}

	@Override
	public void cross(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.40*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the cross");
		damage(attacker, damage, defender);		
	}

	@Override
	public void leftHookBody(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.25*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the left hook to the body");
		damage(attacker, damage, defender);	
	}

	@Override
	public void leftHookHead(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.5*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the left hook to the head");
		damage(attacker, damage, defender);	
	}

	@Override
	public void rightHookBody(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.25*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the right hook to the body");
		damage(attacker, damage, defender);	
	}

	@Override
	public void rightHookHead(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.5*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the right hook to the head");
		damage(attacker, damage, defender);	
	}

	@Override
	public void uppercut(heavyWeight attacker, heavyWeight defender) {
		int damage = (int) (0.35*attacker.getFighterPower());
		System.out.println(attacker.getFighterName() + " used the uppercut");
		damage(attacker, damage, defender);	
	}

	// used to recover stamina
	@Override
	public void clinch(heavyWeight attacker, heavyWeight defender) {
		System.out.println(attacker.getFighterName() + " Clinches");
		attacker.setFighterStamina(attacker.getFighterStamina() + 10);
	}

	//getters and setters

	@Override
	public int getFighterSpeed() {
		return fighterSpeed;
	}

	@Override
	public void setFighterSpeed(int fighterSpeed) {
		this.fighterSpeed = fighterSpeed;
	}

	@Override
	public int getFighterToughness() {
		return fighterToughness;
	}

	@Override
	public void setFighterToughness(int fighterToughness) {
		this.fighterToughness = fighterToughness;
	}

	@Override
	public int getFighterStamina() {
		return fighterStamina;
	}

	@Override
	public void setFighterStamina(int fighterStamina) {
		this.fighterStamina = fighterStamina;
	}

	@Override
	public int getFighterPower() {
		return fighterPower;
	}

	@Override
	public void setFighterPower(int fighterPower) {
		this.fighterPower = fighterPower;
	}
	
	@Override
	public float getFighterHeight() {
		return fighterHeight;
	}

	@Override
	public void setFighterHeight(float fighterHeight) {
		this.fighterHeight = fighterHeight;
	}

	@Override
	public float getFighterWeight() {
		return fighterWeight;
	}

	@Override
	public void setFighterWeight(float fighterWeight) {
		this.fighterWeight = fighterWeight;
	}

	@Override
	public String getFighterName() {
		return fighterName;
	}

	@Override
	public void setFighterName(String fighterName) {
		this.fighterName = fighterName;
	}
	
	@Override
	public int getFighterHealth() {
		return fighterHealth;
	}

	@Override
	public void setFighterHealth(int fighterHealth) {
		this.fighterHealth = fighterHealth;
		
	}

}
