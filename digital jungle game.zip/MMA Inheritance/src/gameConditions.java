import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class gameConditions {
	
	static heavyWeight[] fighters;
	private int numOfFighters, yourFighter, opponentFighter; 
	
	// check to see how many players
	// check to see if a players health has reached 0 
	// maybe you can implement rounds
	
	public void welcome() {
		System.out.println("WELCOME TO THE DIGITAL JUNGLE");
		System.out.println("**************************************************");
		System.out.println("**************************************************");
	}
	
	// determines the number of players playing the game
	public void fighters() {
		boolean isNum = false;
		Scanner scanner = new Scanner (System.in);
		
		do {
			try {
				System.out.println("How many fighters would you like to create? (must be 2 or more) : ");
				setNumOfFighters(scanner.nextInt());
				if(getNumOfFighters() >=2)
				isNum = true;
				else {
					isNum = false;
					System.out.println("You must create 2 or more fighters!");
				}
			}
			// not a real int
			catch(InputMismatchException e) {
				System.out.println("This is not a number. Please Type in a real number!");
				// reset the scanner and set it to next so it is ready to fetch the next information
				scanner.reset();
				scanner.next();
			}
			
		} while(isNum == false);
		System.out.println("Great... " + getNumOfFighters() + " players. Let's get ready to rumble! ");
	}
	
	//fighter Set Up
	public void fighterSetUp(heavyWeight[] boxers) {
		Scanner scanner = new Scanner (System.in);
		boolean isValid = false;


		System.out.println("Time to start Creating The Fighters!");
		System.out.println("**************************************************");
		for( int i =0; i<this.numOfFighters; i++) {
			boxers[i] = new heavyWeight();
		do {
			try {
				isValid = false;

				System.out.print("What will you name Fighter " + (i+1));
				
				boxers[i].setFighterName(scanner.nextLine());

				System.out.println("How much power will he have? (Type a number) ");
				boxers[i].setFighterPower(scanner.nextInt());
				
				System.out.println("How much stamina will he have? (Type a number) ");
				boxers[i].setFighterStamina(scanner.nextInt());
				
				System.out.println("How much speed will he have? (Type a number) ");
				boxers[i].setFighterSpeed(scanner.nextInt());
				
				System.out.println("How much toughness will he have? (Type a number) ");
				boxers[i].setFighterToughness(scanner.nextInt());
				
				System.out.println("How much will he weigh? (Type a number) ");
				boxers[i].setFighterWeight(scanner.nextInt());
				
				System.out.println("How tall will he be in Centimeters? (Type a number) ");
				boxers[i].setFighterHeight(scanner.nextInt());
				scanner.nextLine(); // you have to add nextLine because scanner has a bug look for knute snortum https://coderanch.com/t/680162/java/code-skip-scanner-input 
				
				isValid = true;

			}
			// not a real int
			catch(InputMismatchException e) {
				System.out.println("Invalid Result, Please type everything properly!");
				scanner.nextLine(); // you have to add nextLine because scanner has a bug look for knute snortum https://coderanch.com/t/680162/java/code-skip-scanner-input 

			}
			
		} while(isValid == false);
		boxers[i].setFighterHealth(100);

		}
		
	}
	
	
	//fighter select. You select your fighter and the computer chooses a random opponent
	public void fighterSelect(heavyWeight[] boxers) {
			System.out.println("SELECT YOUR FIGHTER!");
			System.out.println("Type in the number next to the fighter's name to select the fighter!");

		for(int i =0; i<boxers.length; i++) {
			System.out.println(i + ". " + boxers[i].getFighterName());
		}
		
		// DISPLAY all the fighters and store and force the person to choose a fighter
		boolean isNum = false;
		Scanner scanner = new Scanner (System.in);
		int fighterSelect =0;
		
		do {
			try {
				fighterSelect = scanner.nextInt();
				setNumOfFighters(fighterSelect);
				
				
				if(fighterSelect == 0 || fighterSelect <=boxers.length-1 && fighterSelect >=0 ) {
					isNum = true;
				}
				
				else {
					System.out.print("This is not a valid selection!\n");
					System.out.print("Please Type in a Valid Number:");
					// reset the scanner and set it to next so it is ready to fetch the next information
				}
				
			}
			// not a real int
			catch(InputMismatchException e) {
				System.out.println("This is not a number. Please Type in a real number!");
				// reset the scanner and set it to next so it is ready to fetch the next information
				scanner.reset();
				scanner.next();
			}
			
		} while(isNum == false);
		
		// stores the index of the fighter
		setYourFighter(fighterSelect);
		
		// use a computer to select randomnly a fighter from the pool.
		// if the random number is == to the fighterSelect number then redo it.
	
		Random ran = new Random();		
		boolean uniqueRand = false;
		
		do {
			int computerFighter = ran.nextInt(boxers.length);
			if(computerFighter != fighterSelect ) {
				setOpponentFighter(computerFighter);
				uniqueRand = true;
			}
			
		} while(uniqueRand == false);
		
		
		
		
		
		System.out.println("You've selected " + boxers[fighterSelect].getFighterName() + " and will be fighting " + boxers[getOpponentFighter()].getFighterName());
	}
		
			
	
	
	
	// take two inputs of boxers with their positions and print out two sections
	public String announcement(heavyWeight boxer1, heavyWeight boxer2) {
		return 
				
		"In the red corner The reigning, defending Digital Jungle Heavyweight Champion of the world... " + boxer1.getFighterName() + "!"
		+ " And In the blue corner. The Challenger! " + boxer2.getFighterName() + "!";
	}
	
	// whoever has 0 health is the loser
	public boolean winner(heavyWeight[] boxer) {
		if(boxer[getYourFighter()].getFighterHealth() <= 0) {
			System.out.println("You Lose... and the Computer Wins!");
			return true;
		}
		
		else if(boxer[getOpponentFighter()].getFighterHealth() <= 0) {
			System.out.println("You Win! Congradualtions on your title defence!");
			return true;
		}
		
		//found no winner
		return false;
			
	}
	
	
	
	// setters and getters
	public void setNumOfFighters(int numOfFighters) {
		this.numOfFighters = numOfFighters;
	}
	
	public int getNumOfFighters() {
		return numOfFighters;
	}
	
	public void setYourFighter(int yourFighter) {
		this.yourFighter = yourFighter;
	}
	
	public int getYourFighter() {
		return yourFighter;
	}
	
	public void setOpponentFighter(int opponentFighter) {
		this.opponentFighter = opponentFighter;
	}
	
	public int getOpponentFighter() {
		return opponentFighter;
	}
	
}
