
public interface fighter {
	// damage inflicted to the fighter
	void damage(heavyWeight attacker, int damage, heavyWeight defender);
	
	// setters and getters
	public int getFighterSpeed();
	public void setFighterSpeed(int fighterSpeed);
	
	public int getFighterToughness();
	public void setFighterToughness(int fighterToughness);
	
	public int getFighterStamina();
	public void setFighterStamina(int fighterStamina);
	
	public int getFighterPower();
	public void setFighterPower(int fighterPower);
	
	public float getFighterHeight();
	public void setFighterHeight(float fighterHeight);
	
	public float getFighterWeight();
	public void setFighterWeight(float fighterWeight); 
	
	public String getFighterName();
	public void setFighterName(String fighteName);
	
	public int getFighterHealth();
	public void setFighterHealth(int fighterHealth);
}
