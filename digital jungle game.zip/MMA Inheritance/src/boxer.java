
public abstract class boxer {

	// fighter performs an action based on an input from a number
	public abstract void moveset(heavyWeight boxer, heavyWeight opponent);

	// based from the move set, from the action, we will trigger one of the punches

	public abstract void clinch(heavyWeight boxer, heavyWeight computer);

	public abstract void uppercut(heavyWeight boxer, heavyWeight computer);

	public abstract void rightHookHead(heavyWeight boxer, heavyWeight computer);

	public abstract void rightHookBody(heavyWeight boxer, heavyWeight computer);

	public abstract void leftHookHead(heavyWeight boxer, heavyWeight computer);

	public abstract void leftHookBody(heavyWeight boxer, heavyWeight computer);

	public abstract void cross(heavyWeight boxer, heavyWeight computer);

	public abstract void jab(heavyWeight boxer, heavyWeight computer);

}
