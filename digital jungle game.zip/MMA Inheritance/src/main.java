
public class main {
	public static void main(String args[]) {
		// SET THE GETTER AND SETTER FROR OOPPONENT FIGHTER
		
		
		// make a static number for both the fighters, and we take them out ofthe array
		// can do the same for the game conditions class. Have two vriable and have them as the fighters 
		
		gameConditions game = new gameConditions();
		
		game.welcome();
		game.fighters();
		
		// gets the number of boxers
		heavyWeight[] boxers = new heavyWeight[game.getNumOfFighters()];
		
		// allows the users to set up the fighters
		game.fighterSetUp(boxers);
		
		// fighter select
		game.fighterSelect(boxers);
		
		System.out.print(game.announcement(boxers[game.getYourFighter()], boxers[game.getOpponentFighter()] ));
		boolean foundWinner = false;
		do {

			foundWinner = game.winner(boxers);
			boxers[game.getYourFighter()].moveset(boxers[game.getYourFighter()], boxers[game.getOpponentFighter()]);
			foundWinner = game.winner(boxers);

			
		} while(foundWinner == false);
		
	}
}
